import React, { useState } from "react";
import { songs } from "./data/songs";
import Player from "./components/Player";
import SongCard from "./components/SongsCards";

const App = () => {
  const [currentSong, setCurrentSong] = useState(null);
  const [search, setSearch] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All");
  const [activeTab, setActiveTab] = useState("Home");

  const genres = ["All", ...new Set(songs.map((s) => s.genre))];

  const filteredSongs = songs.filter(
    (song) =>
      (song.title.toLowerCase().includes(search.toLowerCase()) ||
        song.artist.toLowerCase().includes(search.toLowerCase())) &&
      (selectedGenre === "All" || song.genre === selectedGenre)
  );

  return (
    <div className="h-screen bg-[#121212] text-white font-sans pb-32">
      <aside className="w-60 fixed top-0 left-0 h-full bg-black p-6">
        <h1 className="text-2xl font-bold mb-8">Spotify</h1>
        <ul className="space-y-4">
          {['Home', 'Search', 'Your Library'].map((tab) => (
            <li
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`cursor-pointer text-gray-300 hover:text-white ${
                activeTab === tab ? "text-white font-bold" : ""
              }`}
            >
              {tab}
            </li>
          ))}
        </ul>
        <div className="mt-10">
          <h2 className="text-lg text-white mb-2">Genres</h2>
          <div className="flex flex-wrap gap-2">
            {genres.map((genre) => (
              <button
                key={genre}
                className={`text-xs px-2 py-1 rounded-full border ${
                  selectedGenre === genre
                    ? "bg-green-500 border-green-500"
                    : "border-gray-600 hover:border-white"
                }`}
                onClick={() => setSelectedGenre(genre)}
              >
                {genre}
              </button>
            ))}
          </div>
        </div>
      </aside>

      <main className="ml-60 p-6">
        <input
          type="text"
          placeholder="Search songs or artists..."
          className="w-full p-3 mb-6 rounded bg-[#1e1e1e] text-white focus:outline-none"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        {activeTab === "Home" && (
          <>
            <h2 className="text-2xl font-semibold mb-4">Browse</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredSongs.map((song) => (
                <SongCard key={song.id} song={song} onSelect={setCurrentSong} />
              ))}
            </div>
          </>
        )}

        {activeTab === "Search" && (
          <p className="text-white text-lg">Search content will go here...</p>
        )}

        {activeTab === "Your Library" && (
          <p className="text-white text-lg">Library content will go here...</p>
        )}
      </main>

      <Player currentSong={currentSong} clearSong={() => setCurrentSong(null)} />
    </div>
  );
};

export default App;
