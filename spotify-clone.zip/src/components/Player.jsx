import React, { useEffect, useRef, useState } from "react";

const Player = ({ currentSong, clearSong }) => {
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (currentSong && audioRef.current) {
      audioRef.current.load();
      audioRef.current.play();
      setIsPlaying(true);
    }
  }, [currentSong]);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  if (!currentSong) return null;

  return (
    <div className="fixed bottom-0 left-0 w-full bg-[#181818] text-white p-4 px-6 flex items-center justify-between shadow-xl z-50">
      <div className="flex items-center gap-4">
        <img src={currentSong.image} alt={currentSong.title} className="w-12 h-12 object-cover rounded" />
        <div>
          <h4 className="text-sm font-semibold">{currentSong.title}</h4>
          <p className="text-xs text-gray-400">{currentSong.artist}</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button onClick={togglePlay} className="bg-green-500 text-black rounded-full px-4 py-1 text-sm font-bold">
          {isPlaying ? "Pause" : "Play"}
        </button>
        <button onClick={clearSong} className="text-gray-400 hover:text-white text-xl font-bold">
          ✖
        </button>
      </div>

      <audio ref={audioRef}>
        <source src={currentSong.audio} type="audio/mpeg" />
      </audio>
    </div>
  );
};

export default Player;
