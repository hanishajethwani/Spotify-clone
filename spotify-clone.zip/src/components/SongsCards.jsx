const SongCard = ({ song, onSelect }) => {
  return (
    <div
      className="bg-white p-4 rounded-lg shadow hover:bg-gray-100 cursor-pointer transition"
      onClick={() => onSelect(song)}
    >
      <img src={song.image} alt={song.title} className="w-full h-40 object-cover rounded-md" />
      <h3 className="mt-2 font-bold text-lg">{song.title}</h3>
      <p className="text-gray-600">{song.artist}</p>
      <p className="text-sm italic text-blue-500">{song.album} • {song.genre}</p>
    </div>
  );
};

export default SongCard;
